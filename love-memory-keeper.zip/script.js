// 全局变量
let memories = JSON.parse(localStorage.getItem('loveMemories')) || [];
let anniversaries = JSON.parse(localStorage.getItem('loveAnniversaries')) || [];
let messages = JSON.parse(localStorage.getItem('loveMessages')) || [];
let currentDate = new Date();
let selectedPhotos = [];
let selectedLocation = null;
let memoryMap = null;
let editingMemoryId = null;
let editingAnniversaryId = null;

// 辅助函数：生成本地日期字符串 (YYYY-MM-DD格式)
function getLocalDateString(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 初始化页面
    renderMemories();
    renderAnniversaries();
    renderCalendar();
    renderMessages();
    
    // 设置默认日期为今天
    document.getElementById('memory-date').valueAsDate = new Date();
    document.getElementById('anniversary-date').valueAsDate = new Date();
    
    // 绑定卡片点击事件
    document.querySelectorAll('.card').forEach(card => {
        card.addEventListener('click', function() {
            const pageName = this.getAttribute('data-page');
            showPage(pageName);
        });
    });
    
    // 绑定返回按钮点击事件
    document.querySelectorAll('.back-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            showPage('home');
        });
    });
    
    // 绑定表单提交事件
    document.getElementById('memory-form').addEventListener('submit', function(e) {
        e.preventDefault();
        if (editingMemoryId) {
            updateMemory();
        } else {
            addMemory();
        }
    });
    
    // 绑定纪念日表单提交事件
    document.getElementById('anniversary-form').addEventListener('submit', function(e) {
        e.preventDefault();
        if (editingAnniversaryId) {
            updateAnniversary();
        } else {
            addAnniversary();
        }
    });
    
    // 绑定留言表单提交事件
    document.getElementById('message-form').addEventListener('submit', function(e) {
        e.preventDefault();
        addMessage();
    });
    
    // 绑定AI查询事件
    document.getElementById('ai-submit').addEventListener('click', function() {
        sendAIQuery();
    });
    
    // 绑定AI输入框回车事件
    document.getElementById('ai-query').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendAIQuery();
        }
    });
    
    // 绑定AI快捷按钮事件
    document.querySelectorAll('.quick-action-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const query = this.getAttribute('data-query');
            document.getElementById('ai-query').value = query;
            sendAIQuery();
        });
    });
    
    // 绑定日历导航事件
    document.getElementById('prev-month').addEventListener('click', function() {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderCalendar();
    });
    
    document.getElementById('next-month').addEventListener('click', function() {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderCalendar();
    });
    
    // 绑定月份点击事件（修改年份）
    document.getElementById('current-month').addEventListener('click', function() {
        const yearSelector = document.getElementById('year-selector');
        const yearInput = document.getElementById('year-input');
        yearInput.value = currentDate.getFullYear();
        yearSelector.style.display = 'flex';
    });
    
    // 绑定年份确认按钮
    document.getElementById('year-confirm').addEventListener('click', function() {
        const yearInput = document.getElementById('year-input');
        const newYear = parseInt(yearInput.value);
        if (newYear >= 1900 && newYear <= 2100) {
            currentDate.setFullYear(newYear);
            renderCalendar();
            document.getElementById('year-selector').style.display = 'none';
        } else {
            alert('请输入有效的年份（1900-2100）');
        }
    });
    
    // 绑定日期范围切换事件
    document.getElementById('date-range-toggle').addEventListener('change', function() {
        const singleDateContainer = document.getElementById('single-date-container');
        const dateRangeContainer = document.getElementById('date-range-container');
        
        if (this.checked) {
            singleDateContainer.style.display = 'none';
            dateRangeContainer.style.display = 'block';
            document.getElementById('memory-start-date').valueAsDate = new Date();
            document.getElementById('memory-end-date').valueAsDate = new Date();
        } else {
            singleDateContainer.style.display = 'block';
            dateRangeContainer.style.display = 'none';
        }
    });
    
    // 绑定照片上传事件
    document.getElementById('photo-upload').addEventListener('change', function(e) {
        handlePhotoUpload(e);
    });
    
    // 绑定语音输入事件
    document.getElementById('voice-input-btn').addEventListener('click', function() {
        startVoiceInput();
    });
    
    // 绑定地点搜索事件
    document.getElementById('search-location-btn').addEventListener('click', function() {
        searchLocation();
    });
    
    // 绑定地点输入框回车事件
    document.getElementById('memory-location').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            searchLocation();
        }
    });
    
    // 绑定清除地点按钮
    document.getElementById('clear-location').addEventListener('click', function() {
        clearLocation();
    });
});

// 页面切换函数
function showPage(pageName) {
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    
    let targetPageId;
    if (pageName === 'home') {
        targetPageId = 'home-page';
    } else {
        targetPageId = pageName + '-page';
    }
    
    const targetPage = document.getElementById(targetPageId);
    if (targetPage) {
        targetPage.classList.add('active');
        
        if (pageName === 'calendar') {
            renderCalendar();
        } else if (pageName === 'memories') {
            renderMemories();
        } else if (pageName === 'anniversary') {
            renderAnniversaries();
        } else if (pageName === 'messages') {
            renderMessages();
        } else if (pageName === 'map') {
            setTimeout(() => {
                initMap();
            }, 100);
        }
    }
}

// 初始化百度地图
function initMap() {
    // 检查百度地图API是否加载成功
    if (typeof BMap === 'undefined') {
        document.getElementById('memory-map').innerHTML = `
            <div style="display: flex; align-items: center; justify-content: center; height: 100%; background: #f5f5f5; border: 2px dashed #ccc; border-radius: 8px;">
                <div style="text-align: center; padding: 20px;">
                    <p style="color: #666; margin-bottom: 10px;">百度地图加载失败</p>
                    <p style="color: #999; font-size: 0.5rem;">请检查网络连接</p>
                </div>
            </div>
        `;
        return;
    }
    
    // 创建地图实例
    memoryMap = new BMap.Map('memory-map');
    
    // 设置中心点（中国中心）
    const point = new BMap.Point(104.1954, 35.8617);
    memoryMap.centerAndZoom(point, 5);
    
    // 添加地图控件
    memoryMap.addControl(new BMap.NavigationControl());
    memoryMap.addControl(new BMap.ScaleControl());
    memoryMap.addControl(new BMap.OverviewMapControl());
    memoryMap.enableScrollWheelZoom(true);
    
    // 添加有地点的记忆标记
    const memoriesWithLocation = memories.filter(m => m.location && m.location.lat && m.location.lng);
    
    if (memoriesWithLocation.length > 0) {
        const points = [];
        
        memoriesWithLocation.forEach(memory => {
            const markerPoint = new BMap.Point(memory.location.lng, memory.location.lat);
            points.push(markerPoint);
            
            const marker = new BMap.Marker(markerPoint);
            memoryMap.addOverlay(marker);
            
            const typeNames = {
                date: '约会',
                milestone: '里程碑',
                story: '故事',
                travel: '旅行'
            };
            
            const infoWindow = new BMap.InfoWindow(`
                <div style="font-family: sans-serif; max-width: 200px; padding: 10px;">
                    <strong style="color: #ff4757;">${typeNames[memory.type]}</strong><br>
                    <p style="margin: 5px 0; font-size: 12px; color: #333;">${memory.content.substring(0, 50)}${memory.content.length > 50 ? '...' : ''}</p>
                    <small style="color: #666;">${formatDate(memory.date)}</small>
                </div>
            `);
            
            marker.addEventListener('click', function() {
                this.openInfoWindow(infoWindow);
            });
        });
        
        // 调整视野以显示所有标记
        memoryMap.setViewport(points);
    }
}

// 搜索地点 - 使用百度地图本地搜索
function searchLocation() {
    const query = document.getElementById('memory-location').value.trim();
    if (!query) {
        alert('请输入地点名称');
        return;
    }
    
    const resultsContainer = document.getElementById('location-results');
    resultsContainer.innerHTML = '<p style="padding: 10px; font-size: 0.55rem;">搜索中...</p>';
    
    // 检查百度地图API是否可用
    if (typeof BMap === 'undefined') {
        // 如果百度地图API不可用，使用备用方案
        resultsContainer.innerHTML = `
            <div style="padding: 15px; text-align: center;">
                <p style="font-size: 0.55rem; color: #666; margin-bottom: 10px;">地图服务暂时不可用</p>
                <button class="btn" style="font-size: 0.5rem; padding: 8px 15px;" onclick="useManualLocation('${query.replace(/'/g, "\\'")}')">
                    使用 "${query}" 作为地点
                </button>
            </div>
        `;
        return;
    }
    
    // 创建本地搜索实例
    const localSearch = new BMap.LocalSearch(new BMap.Map(), {
        onSearchComplete: function(results) {
            if (localSearch.getStatus() == BMAP_STATUS_SUCCESS) {
                if (results.getNumPois() === 0) {
                    resultsContainer.innerHTML = '<p style="padding: 10px; font-size: 0.55rem;">未找到地点，请尝试其他关键词</p>';
                    return;
                }
                
                resultsContainer.innerHTML = '';
                for (let i = 0; i < Math.min(results.getNumPois(), 5); i++) {
                    const poi = results.getPoi(i);
                    const item = document.createElement('div');
                    item.className = 'location-result-item';
                    item.textContent = poi.title + (poi.address ? ' - ' + poi.address : '');
                    item.title = poi.title;
                    item.addEventListener('click', function() {
                        selectLocation({
                            name: poi.title,
                            lat: poi.point.lat,
                            lng: poi.point.lng
                        });
                        resultsContainer.innerHTML = '';
                    });
                    resultsContainer.appendChild(item);
                }
            } else {
                resultsContainer.innerHTML = '<p style="padding: 10px; font-size: 0.55rem;">搜索失败，请重试</p>';
            }
        },
        onSearchError: function() {
            resultsContainer.innerHTML = `
                <div style="padding: 15px; text-align: center;">
                    <p style="font-size: 0.55rem; color: #666; margin-bottom: 10px;">搜索失败</p>
                    <button class="btn" style="font-size: 0.5rem; padding: 8px 15px;" onclick="useManualLocation('${query.replace(/'/g, "\\'")}')">
                        使用 "${query}" 作为地点
                    </button>
                </div>
            `;
        }
    });
    
    // 执行搜索
    localSearch.search(query);
}

// 手动使用地点
function useManualLocation(name) {
    // 使用默认坐标（中国中心位置）
    selectLocation({
        name: name,
        lat: 35.8617,
        lng: 104.1954
    });
    document.getElementById('location-results').innerHTML = '';
}

// 选择地点
function selectLocation(location) {
    selectedLocation = location;
    document.getElementById('selected-location').style.display = 'flex';
    document.getElementById('selected-location-name').textContent = location.name;
    document.getElementById('memory-location').value = '';
}

// 清除地点
function clearLocation() {
    selectedLocation = null;
    document.getElementById('selected-location').style.display = 'none';
    document.getElementById('selected-location-name').textContent = '';
}

// 开始语音输入
function startVoiceInput() {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        alert('您的浏览器不支持语音输入功能');
        return;
    }
    
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    const voiceBtn = document.getElementById('voice-input-btn');
    const contentTextarea = document.getElementById('memory-content');
    
    recognition.lang = 'zh-CN';
    recognition.continuous = false;
    recognition.interimResults = false;
    
    voiceBtn.classList.add('recording');
    voiceBtn.textContent = '🔴';
    
    recognition.start();
    
    recognition.onresult = function(event) {
        const transcript = event.results[0][0].transcript;
        contentTextarea.value += transcript;
    };
    
    recognition.onerror = function(event) {
        alert('语音识别出错：' + event.error);
        voiceBtn.classList.remove('recording');
        voiceBtn.textContent = '🎤';
    };
    
    recognition.onend = function() {
        voiceBtn.classList.remove('recording');
        voiceBtn.textContent = '🎤';
    };
}

// 添加新记忆
function addMemory() {
    const type = document.getElementById('memory-type').value;
    const content = document.getElementById('memory-content').value;
    const isDateRange = document.getElementById('date-range-toggle').checked;
    
    if (!content) {
        alert('请输入记忆内容');
        return;
    }
    
    let dateInfo;
    if (isDateRange) {
        const startDate = document.getElementById('memory-start-date').value;
        const endDate = document.getElementById('memory-end-date').value;
        
        if (!startDate || !endDate) {
            alert('请选择开始和结束日期');
            return;
        }
        
        if (new Date(startDate) > new Date(endDate)) {
            alert('开始日期不能晚于结束日期');
            return;
        }
        
        dateInfo = {
            isRange: true,
            startDate: startDate,
            endDate: endDate,
            date: startDate
        };
    } else {
        const date = document.getElementById('memory-date').value;
        if (!date) {
            alert('请选择日期');
            return;
        }
        dateInfo = {
            isRange: false,
            date: date
        };
    }
    
    const memory = {
        id: Date.now(),
        type: type,
        content: content,
        date: dateInfo.date,
        dateRange: dateInfo.isRange ? {
            start: dateInfo.startDate,
            end: dateInfo.endDate
        } : null,
        location: selectedLocation,
        createdAt: new Date().toISOString(),
        photos: selectedPhotos
    };
    
    memories.push(memory);
    localStorage.setItem('loveMemories', JSON.stringify(memories));
    
    resetMemoryForm();
    renderMemories();
    renderCalendar();
    showNotification('记忆添加成功！');
}

// 更新记忆
function updateMemory() {
    const type = document.getElementById('memory-type').value;
    const content = document.getElementById('memory-content').value;
    const isDateRange = document.getElementById('date-range-toggle').checked;
    
    if (!content) {
        alert('请输入记忆内容');
        return;
    }
    
    let dateInfo;
    if (isDateRange) {
        const startDate = document.getElementById('memory-start-date').value;
        const endDate = document.getElementById('memory-end-date').value;
        
        if (!startDate || !endDate) {
            alert('请选择开始和结束日期');
            return;
        }
        
        if (new Date(startDate) > new Date(endDate)) {
            alert('开始日期不能晚于结束日期');
            return;
        }
        
        dateInfo = {
            isRange: true,
            startDate: startDate,
            endDate: endDate,
            date: startDate
        };
    } else {
        const date = document.getElementById('memory-date').value;
        if (!date) {
            alert('请选择日期');
            return;
        }
        dateInfo = {
            isRange: false,
            date: date
        };
    }
    
    const memoryIndex = memories.findIndex(m => m.id === editingMemoryId);
    if (memoryIndex !== -1) {
        memories[memoryIndex] = {
            ...memories[memoryIndex],
            type: type,
            content: content,
            date: dateInfo.date,
            dateRange: dateInfo.isRange ? {
                start: dateInfo.startDate,
                end: dateInfo.endDate
            } : null,
            location: selectedLocation,
            photos: selectedPhotos,
            updatedAt: new Date().toISOString()
        };
        
        localStorage.setItem('loveMemories', JSON.stringify(memories));
        editingMemoryId = null;
        
        resetMemoryForm();
        renderMemories();
        renderCalendar();
        showNotification('记忆更新成功！');
    }
}

// 重置记忆表单
function resetMemoryForm() {
    document.getElementById('memory-form').reset();
    document.getElementById('memory-form-title').textContent = '添加新记忆';
    document.getElementById('memory-submit-btn').textContent = '保存记忆';
    document.getElementById('memory-id').value = '';
    selectedPhotos = [];
    selectedLocation = null;
    document.getElementById('selected-location').style.display = 'none';
    document.getElementById('single-date-container').style.display = 'block';
    document.getElementById('date-range-container').style.display = 'none';
    document.getElementById('date-range-toggle').checked = false;
    
    const gallery = document.querySelector('#photo-upload-container .photo-gallery');
    if (gallery) {
        gallery.remove();
    }
    
    document.getElementById('memory-date').valueAsDate = new Date();
}

// 编辑记忆
function editMemory(id) {
    const memory = memories.find(m => m.id === id);
    if (!memory) return;
    
    editingMemoryId = id;
    document.getElementById('memory-form-title').textContent = '编辑记忆';
    document.getElementById('memory-submit-btn').textContent = '更新记忆';
    document.getElementById('memory-id').value = id;
    document.getElementById('memory-type').value = memory.type;
    document.getElementById('memory-content').value = memory.content;
    
    if (memory.dateRange) {
        document.getElementById('date-range-toggle').checked = true;
        document.getElementById('single-date-container').style.display = 'none';
        document.getElementById('date-range-container').style.display = 'block';
        document.getElementById('memory-start-date').value = memory.dateRange.start;
        document.getElementById('memory-end-date').value = memory.dateRange.end;
    } else {
        document.getElementById('date-range-toggle').checked = false;
        document.getElementById('single-date-container').style.display = 'block';
        document.getElementById('date-range-container').style.display = 'none';
        document.getElementById('memory-date').value = memory.date;
    }
    
    if (memory.location) {
        selectedLocation = memory.location;
        document.getElementById('selected-location').style.display = 'flex';
        document.getElementById('selected-location-name').textContent = memory.location.name;
    }
    
    if (memory.photos && memory.photos.length > 0) {
        selectedPhotos = [...memory.photos];
        renderSelectedPhotos();
    }
    
    showPage('add-memory');
}

// 添加纪念日
function addAnniversary() {
    const name = document.getElementById('anniversary-name').value;
    const date = document.getElementById('anniversary-date').value;
    const description = document.getElementById('anniversary-description').value;
    
    if (!name || !date) {
        alert('请输入纪念日名称和日期');
        return;
    }
    
    const anniversary = {
        id: Date.now(),
        name: name,
        date: date,
        description: description,
        createdAt: new Date().toISOString()
    };
    
    anniversaries.push(anniversary);
    localStorage.setItem('loveAnniversaries', JSON.stringify(anniversaries));
    
    resetAnniversaryForm();
    renderAnniversaries();
    renderCalendar();
    showNotification('纪念日添加成功！');
}

// 渲染纪念日列表
function renderAnniversaries() {
    const anniversariesList = document.getElementById('anniversaries-list');
    anniversariesList.innerHTML = '';
    
    if (anniversaries.length === 0) {
        anniversariesList.innerHTML = '<p class="no-anniversaries">还没有添加纪念日，快来添加吧！</p>';
        return;
    }
    
    const sortedAnniversaries = [...anniversaries].sort((a, b) => {
        const dateA = new Date(a.date);
        const dateB = new Date(b.date);
        dateA.setFullYear(new Date().getFullYear());
        dateB.setFullYear(new Date().getFullYear());
        return dateA - dateB;
    });
    
    sortedAnniversaries.forEach(anniversary => {
        const anniversaryItem = document.createElement('div');
        anniversaryItem.className = 'anniversary-item';
        
        const daysLeft = getDaysUntilAnniversary(anniversary.date);
        
        anniversaryItem.innerHTML = `
            <h3>${anniversary.name}</h3>
            <p class="date">${formatDate(anniversary.date)}</p>
            <p>${anniversary.description || '无描述'}</p>
            <p class="days-left">距离今年还有 ${daysLeft} 天</p>
            <div class="anniversary-actions">
                <button class="btn btn-edit" onclick="editAnniversary(${anniversary.id})">修改</button>
                <button class="btn btn-delete" onclick="deleteAnniversary(${anniversary.id})">删除</button>
            </div>
        `;
        
        anniversariesList.appendChild(anniversaryItem);
    });
}

// 编辑纪念日
function editAnniversary(id) {
    const anniversary = anniversaries.find(a => a.id === id);
    if (!anniversary) return;
    
    editingAnniversaryId = id;
    document.getElementById('anniversary-form-title').textContent = '编辑纪念日';
    document.getElementById('anniversary-submit-btn').textContent = '更新纪念日';
    document.getElementById('anniversary-id').value = id;
    document.getElementById('anniversary-name').value = anniversary.name;
    document.getElementById('anniversary-date').value = anniversary.date;
    document.getElementById('anniversary-description').value = anniversary.description || '';
}

// 更新纪念日
function updateAnniversary() {
    const name = document.getElementById('anniversary-name').value;
    const date = document.getElementById('anniversary-date').value;
    const description = document.getElementById('anniversary-description').value;
    
    if (!name || !date) {
        alert('请输入纪念日名称和日期');
        return;
    }
    
    const anniversaryIndex = anniversaries.findIndex(a => a.id === editingAnniversaryId);
    if (anniversaryIndex !== -1) {
        anniversaries[anniversaryIndex] = {
            ...anniversaries[anniversaryIndex],
            name: name,
            date: date,
            description: description,
            updatedAt: new Date().toISOString()
        };
        
        localStorage.setItem('loveAnniversaries', JSON.stringify(anniversaries));
        editingAnniversaryId = null;
        
        resetAnniversaryForm();
        renderAnniversaries();
        renderCalendar();
        showNotification('纪念日更新成功！');
    }
}

// 重置纪念日表单
function resetAnniversaryForm() {
    document.getElementById('anniversary-form').reset();
    document.getElementById('anniversary-form-title').textContent = '纪念日管理';
    document.getElementById('anniversary-submit-btn').textContent = '添加纪念日';
    document.getElementById('anniversary-id').value = '';
}

// 删除纪念日
function deleteAnniversary(id) {
    if (confirm('确定要删除这个纪念日吗？')) {
        anniversaries = anniversaries.filter(anniversary => anniversary.id !== id);
        localStorage.setItem('loveAnniversaries', JSON.stringify(anniversaries));
        renderAnniversaries();
        renderCalendar();
        showNotification('纪念日已删除');
    }
}

// 计算距离纪念日的天数
function getDaysUntilAnniversary(anniversaryDate) {
    const today = new Date();
    const anniversary = new Date(anniversaryDate);
    anniversary.setFullYear(today.getFullYear());
    
    if (anniversary < today) {
        anniversary.setFullYear(today.getFullYear() + 1);
    }
    
    const timeDiff = anniversary - today;
    return Math.ceil(timeDiff / (1000 * 3600 * 24));
}

// 渲染日历
function renderCalendar() {
    const calendar = document.getElementById('calendar');
    const currentMonthElement = document.getElementById('current-month');
    
    const monthNames = ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'];
    currentMonthElement.textContent = `${currentDate.getFullYear()}年 ${monthNames[currentDate.getMonth()]}`;
    
    calendar.innerHTML = '';
    
    const weekDays = ['日', '一', '二', '三', '四', '五', '六'];
    weekDays.forEach(day => {
        const dayElement = document.createElement('div');
        dayElement.className = 'calendar-header';
        dayElement.textContent = day;
        calendar.appendChild(dayElement);
    });
    
    const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    const startDay = firstDay.getDay();
    const daysInMonth = lastDay.getDate();
    
    // 上个月
    for (let i = startDay - 1; i >= 0; i--) {
        const prevDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), -i);
        const dayElement = document.createElement('div');
        dayElement.className = 'calendar-day other-month';
        dayElement.textContent = prevDay.getDate();
        
        const dateString = getLocalDateString(prevDay);
        addCalendarDayEvents(dayElement, dateString, prevDay);
        calendar.appendChild(dayElement);
    }
    
    // 当月
    for (let i = 1; i <= daysInMonth; i++) {
        const day = new Date(currentDate.getFullYear(), currentDate.getMonth(), i);
        const dayElement = document.createElement('div');
        dayElement.className = 'calendar-day';
        dayElement.textContent = i;
        
        const today = new Date();
        if (day.getDate() === today.getDate() && day.getMonth() === today.getMonth() && day.getFullYear() === today.getFullYear()) {
            dayElement.classList.add('today');
        }
        
        const dateString = getLocalDateString(day);
        addCalendarDayEvents(dayElement, dateString, day);
        calendar.appendChild(dayElement);
    }
    
    // 下个月
    const remainingDays = 42 - (startDay + daysInMonth);
    for (let i = 1; i <= remainingDays; i++) {
        const nextDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, i);
        const dayElement = document.createElement('div');
        dayElement.className = 'calendar-day other-month';
        dayElement.textContent = nextDay.getDate();
        
        const dateString = getLocalDateString(nextDay);
        addCalendarDayEvents(dayElement, dateString, nextDay);
        calendar.appendChild(dayElement);
    }
}

// 添加日历日期事件
function addCalendarDayEvents(dayElement, dateString, day) {
    const hasMemory = memories.some(memory => memory.date === dateString);
    const hasAnniversary = anniversaries.some(anniversary => {
        const annivDate = new Date(anniversary.date);
        return annivDate.getMonth() === day.getMonth() && annivDate.getDate() === day.getDate();
    });
    
    if (hasMemory) {
        dayElement.classList.add('has-memory');
    }
    if (hasAnniversary) {
        dayElement.classList.add('has-anniversary');
    }
    
    if (hasMemory || hasAnniversary) {
        const dayEvents = document.createElement('div');
        dayEvents.className = 'day-events';
        if (hasMemory) {
            const memoryDot = document.createElement('div');
            memoryDot.className = 'event-dot';
            memoryDot.style.backgroundColor = '#ffd700';
            dayEvents.appendChild(memoryDot);
        }
        if (hasAnniversary) {
            const anniversaryDot = document.createElement('div');
            anniversaryDot.className = 'event-dot';
            anniversaryDot.style.backgroundColor = '#00ff80';
            dayEvents.appendChild(anniversaryDot);
        }
        dayElement.appendChild(dayEvents);
    }
    
    dayElement.addEventListener('click', function() {
        showDayMemories(dateString);
    });
}

// 显示某天的记忆
function showDayMemories(dateString) {
    const dayMemories = memories.filter(memory => memory.date === dateString);
    const dayAnniversaries = anniversaries.filter(anniversary => {
        const annivDate = new Date(anniversary.date);
        const targetDate = new Date(dateString);
        return annivDate.getMonth() === targetDate.getMonth() && annivDate.getDate() === targetDate.getDate();
    });
    
    let message = `日期：${formatDate(dateString)}\n\n`;
    
    if (dayAnniversaries.length > 0) {
        message += '纪念日：\n';
        dayAnniversaries.forEach(anniversary => {
            message += `- ${anniversary.name}\n`;
        });
        message += '\n';
    }
    
    if (dayMemories.length > 0) {
        message += '记忆：\n';
        dayMemories.forEach(memory => {
            message += `- ${memory.content}\n`;
        });
    } else {
        message += '这一天还没有记忆，快来添加吧！';
    }
    
    alert(message);
}

// 处理照片上传
function handlePhotoUpload(e) {
    const files = e.target.files;
    if (files.length === 0) return;
    
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (!file.type.startsWith('image/')) {
            alert('请上传图片文件');
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(e) {
            selectedPhotos.push(e.target.result);
            renderSelectedPhotos();
        };
        reader.readAsDataURL(file);
    }
}

// 渲染选中的照片
function renderSelectedPhotos() {
    const photoUploadContainer = document.getElementById('photo-upload-container');
    let gallery = photoUploadContainer.querySelector('.photo-gallery');
    
    if (!gallery) {
        gallery = document.createElement('div');
        gallery.className = 'photo-gallery';
        photoUploadContainer.appendChild(gallery);
    }
    
    gallery.innerHTML = '';
    
    selectedPhotos.forEach((photo, index) => {
        const photoItem = document.createElement('div');
        photoItem.className = 'photo-item';
        photoItem.innerHTML = `
            <img src="${photo}" alt="上传的照片">
            <button class="delete-photo" onclick="deletePhoto(${index})">×</button>
        `;
        gallery.appendChild(photoItem);
    });
}

// 删除选中的照片
function deletePhoto(index) {
    selectedPhotos.splice(index, 1);
    renderSelectedPhotos();
}

// 渲染记忆列表
function renderMemories() {
    const memoriesList = document.getElementById('memories-list');
    memoriesList.innerHTML = '';
    
    if (memories.length === 0) {
        memoriesList.innerHTML = '<p class="no-memories">还没有记忆，快来添加吧！</p>';
        return;
    }
    
    const sortedMemories = [...memories].sort((a, b) => new Date(b.date) - new Date(a.date));
    
    sortedMemories.forEach(memory => {
        const memoryItem = document.createElement('div');
        memoryItem.className = 'memory-item';
        
        const typeNames = {
            date: '约会',
            milestone: '里程碑',
            story: '故事',
            travel: '旅行'
        };
        
        let dateDisplay;
        if (memory.dateRange) {
            dateDisplay = `${formatDate(memory.dateRange.start)} - ${formatDate(memory.dateRange.end)}`;
        } else {
            dateDisplay = formatDate(memory.date);
        }
        
        let locationDisplay = '';
        if (memory.location) {
            locationDisplay = `<p class="memory-location">📍 ${memory.location.name.split(',')[0]}</p>`;
        }
        
        let photoGallery = '';
        if (memory.photos && memory.photos.length > 0) {
            photoGallery = '<div class="photo-gallery">';
            memory.photos.forEach(photo => {
                photoGallery += `<div class="photo-item"><img src="${photo}" alt="记忆照片"></div>`;
            });
            photoGallery += '</div>';
        }
        
        memoryItem.innerHTML = `
            <h3>${typeNames[memory.type]}</h3>
            ${locationDisplay}
            <p>${memory.content}</p>
            ${photoGallery}
            <p class="date">${dateDisplay}</p>
            <div class="memory-actions">
                <button class="btn btn-edit" onclick="editMemory(${memory.id})">修改</button>
                <button class="btn btn-delete" onclick="deleteMemory(${memory.id})">删除</button>
            </div>
        `;
        
        memoriesList.appendChild(memoryItem);
    });
}

// 删除记忆
function deleteMemory(id) {
    if (confirm('确定要删除这个记忆吗？')) {
        memories = memories.filter(memory => memory.id !== id);
        localStorage.setItem('loveMemories', JSON.stringify(memories));
        renderMemories();
        renderCalendar();
        showNotification('记忆已删除');
    }
}

// 发送AI查询
function sendAIQuery() {
    const query = document.getElementById('ai-query').value.trim();
    const aiResponse = document.getElementById('ai-response');
    
    if (!query) {
        alert('请输入查询内容');
        return;
    }
    
    aiResponse.innerHTML = '<div class="loading"></div><p>正在分析你们的记忆...</p>';
    
    setTimeout(() => {
        const response = getAIResponse(query);
        aiResponse.innerHTML = `<p>${response}</p>`;
        document.getElementById('ai-query').value = '';
    }, 1500);
}

// 获取AI响应
function getAIResponse(query) {
    // 分析记忆数据
    const totalMemories = memories.length;
    const totalAnniversaries = anniversaries.length;
    const locations = memories.filter(m => m.location).map(m => m.location.name.split(',')[0]);
    const types = memories.reduce((acc, m) => {
        acc[m.type] = (acc[m.type] || 0) + 1;
        return acc;
    }, {});
    
    if (query.includes('甜蜜') || query.includes('瞬间')) {
        if (totalMemories === 0) {
            return '你们还没有记录任何记忆呢！快去添加一些甜蜜的瞬间吧！💕';
        }
        
        const recentMemories = memories.slice(-3).reverse();
        let response = `根据你们的 ${totalMemories} 条记忆，我发现了这些甜蜜瞬间：\n\n`;
        recentMemories.forEach((m, i) => {
            const typeNames = { date: '约会', milestone: '里程碑', story: '故事', travel: '旅行' };
            response += `${i + 1}. ${typeNames[m.type]}：${m.content.substring(0, 30)}${m.content.length > 30 ? '...' : ''}\n`;
        });
        response += `\n继续记录更多美好时光吧！每一刻都值得珍藏！💝`;
        return response;
    }
    
    if (query.includes('历程') || query.includes('总结')) {
        if (totalMemories === 0) {
            return '开始记录你们的恋爱历程吧！每一步都是珍贵的回忆！📝';
        }
        
        const firstMemory = memories[0];
        const lastMemory = memories[memories.length - 1];
        let response = `你们的恋爱历程：\n\n`;
        response += `📅 从 ${formatDate(firstMemory.date)} 开始记录\n`;
        response += `💝 共记录了 ${totalMemories} 条记忆\n`;
        response += `💕 ${totalAnniversaries} 个重要纪念日\n`;
        if (locations.length > 0) {
            response += `🗺️ 去过 ${[...new Set(locations)].length} 个不同的地方\n`;
        }
        response += `\n每一段旅程都见证了你们的爱情！继续创造更多美好回忆吧！✨`;
        return response;
    }
    
    if (query.includes('约会') || query.includes('推荐')) {
        if (locations.length === 0) {
            return '你们还没有记录去过的地方呢！快去记录你们的约会地点吧！📍\n\n推荐：可以尝试去公园、咖啡厅、电影院等地方约会哦！';
        }
        
        const uniqueLocations = [...new Set(locations)];
        let response = `你们去过的地方：\n\n`;
        uniqueLocations.slice(0, 5).forEach((loc, i) => {
            response += `${i + 1}. ${loc}\n`;
        });
        response += `\n💡 建议：可以尝试探索新的地方，创造更多新鲜感！`;
        return response;
    }
    
    if (query.includes('爱好') || query.includes('共同')) {
        if (totalMemories === 0) {
            return '记录更多记忆后，我可以帮你们分析共同爱好哦！❤️';
        }
        
        let response = `根据你们的记忆分析：\n\n`;
        Object.entries(types).forEach(([type, count]) => {
            const typeNames = { date: '约会', milestone: '里程碑', story: '故事', travel: '旅行' };
            response += `${typeNames[type]}：${count} 次\n`;
        });
        response += `\n你们最喜欢一起做的事情是${Object.keys(types).reduce((a, b) => types[a] > types[b] ? a : b) === 'date' ? '约会' : Object.keys(types).reduce((a, b) => types[a] > types[b] ? a : b) === 'travel' ? '旅行' : '记录故事'}！继续保持这份热情吧！💕`;
        return response;
    }
    
    // 默认响应
    return `你们已经记录了 ${totalMemories} 条记忆和 ${totalAnniversaries} 个纪念日。\n\n我可以帮你：\n• 分析最甜蜜的瞬间\n• 总结恋爱历程\n• 推荐约会地点\n• 分析共同爱好\n\n试试点击上方的快捷按钮吧！`;
}

// 格式化日期
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// 显示通知
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background-color: #4CAF50;
        color: white;
        padding: 15px 20px;
        border-radius: 5px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        z-index: 1000;
        animation: slideIn 0.3s ease-out;
    `;
    
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
    `;
    document.head.appendChild(style);
    
    setTimeout(() => {
        notification.style.animation = 'slideIn 0.3s ease-out reverse';
        setTimeout(() => {
            document.body.removeChild(notification);
            document.head.removeChild(style);
        }, 300);
    }, 3000);
}

// 添加留言
function addMessage() {
    const content = document.getElementById('message-content').value.trim();
    const mood = document.getElementById('message-mood').value;
    
    if (!content) {
        alert('请输入留言内容');
        return;
    }
    
    const moodNames = {
        love: '❤️ 爱你',
        miss: '💕 想你',
        happy: '😊 开心',
        thanks: '🙏 感谢',
        sorry: '😔 抱歉',
        other: '💭 其他'
    };
    
    const message = {
        id: Date.now(),
        content: content,
        mood: moodNames[mood],
        createdAt: new Date().toISOString()
    };
    
    messages.push(message);
    localStorage.setItem('loveMessages', JSON.stringify(messages));
    
    // 清空表单
    document.getElementById('message-content').value = '';
    document.getElementById('message-mood').value = 'love';
    
    // 重新渲染留言列表
    renderMessages();
    
    // 显示成功提示
    showNotification('留言发送成功！');
}

// 渲染留言列表
function renderMessages() {
    const messagesList = document.getElementById('messages-list');
    messagesList.innerHTML = '';
    
    if (messages.length === 0) {
        messagesList.innerHTML = '<p class="no-messages">还没有留言，快来给TA留言吧！💌</p>';
        return;
    }
    
    // 按时间排序（最新的在前）
    const sortedMessages = [...messages].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    sortedMessages.forEach(message => {
        const messageItem = document.createElement('div');
        messageItem.className = 'message-item';
        
        const messageDate = new Date(message.createdAt);
        const formattedDate = messageDate.toLocaleDateString('zh-CN', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        
        messageItem.innerHTML = `
            <div class="message-header">
                <span class="message-time">${formattedDate}</span>
            </div>
            <div class="message-content">${message.content}</div>
            <div class="message-mood">心情：${message.mood}</div>
            <div class="message-actions">
                <button class="btn btn-delete" onclick="deleteMessage(${message.id})">删除</button>
            </div>
        `;
        
        messagesList.appendChild(messageItem);
    });
}

// 删除留言
function deleteMessage(id) {
    if (confirm('确定要删除这条留言吗？')) {
        messages = messages.filter(message => message.id !== id);
        localStorage.setItem('loveMessages', JSON.stringify(messages));
        renderMessages();
        showNotification('留言已删除');
    }
}